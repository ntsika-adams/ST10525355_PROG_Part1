/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapp;

import java.util.Scanner;
/*
*
*
*@author Student
*/

public class Main {
    public static void main(String[] args) {
        // Scanner allows user to input info
        Scanner input = new Scanner(System.in);

        // Create object for Login class
        Login login = new Login();

        // --- REGISTRATION SECTION ---
        System.out.println("--- USER REGISTRATION ---");

        System.out.print("Enter a username: ");
        String username = input.nextLine().trim();

        System.out.print("Enter a password: ");
        String password = input.nextLine().trim();

        System.out.print("Enter your South African phone number (+27...): ");
        String phoneNumber = input.nextLine().trim();

        // Call registerUser method and store the message it returns
        String response = login.registerUser(username, password, phoneNumber);

        // Show registration message
        System.out.println(response);

        // --- LOGIN SECTION ---
        System.out.println("\n--- USER LOGIN ---");

        System.out.print("Enter your username: ");
        String loginUsername = input.nextLine().trim();

        System.out.print("Enter your password: ");
        String loginPassword = input.nextLine().trim();

        // Call loginUser to check if the details match the stored ones
        boolean loggedIn = login.loginUser(loginUsername, loginPassword);

        // Print out the correct login message
        String loginMessage = login.returnLoginStatus(loggedIn); // FIXED method name
        System.out.println(loginMessage);

        // Close scanner to avoid resource leak
        input.close();
    }
}
