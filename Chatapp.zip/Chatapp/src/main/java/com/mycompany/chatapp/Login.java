/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapp;

/*
*
*@author Student
*/

public class Login {

    // Fields to store username, password, and phone number
    String username;
    String password;
    String phoneNumber;

    // ===============================================================
    //                   USERNAME VALIDATION
    // ===============================================================
    // We are checking to see if the user has entered a username 
    // with 5 or fewer characters and if it has an underscore
    public boolean checkUserName(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    // ===============================================================
    //                   PASSWORD VALIDATION
    // ===============================================================
    // We are making sure that the password is strong and complex enough
    public boolean checkPassword(String password) {
        boolean hasCapital = false;    // Must contain at least one uppercase letter
        boolean hasNumber = false;     // Must contain at least one digit
        boolean hasSpecial = false;    // Must contain at least one special character

        // Check each character of the password
        for (int i = 0; i < password.length(); i++) {
            char c = password.charAt(i);
            if (Character.isUpperCase(c)) {
                hasCapital = true;
            } else if (Character.isDigit(c)) {
                hasNumber = true;
            } else if (!Character.isLetterOrDigit(c)) {
                hasSpecial = true;
            }
        }

        // Password must be at least 8 characters and meet all criteria
        return password.length() >= 8 && hasCapital && hasNumber && hasSpecial;
    }

    // ===============================================================
    //                   PHONE NUMBER VALIDATION
    // ===============================================================
    // We are making sure the phone number starts with +27 (South Africa code)
    // and has exactly 12 characters (+27 followed by 9 digits)
    public boolean phoneNumber(String phone) {
        return phone.startsWith("+27") && phone.length() == 12;
    }

    // ===============================================================
    //                   REGISTER USER
    // ===============================================================
    // This method registers the user if all inputs are valid
    public String registerUser(String username, String password, String phoneNumber) {
        if (!checkUserName(username)) {
            return "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.";
        }
        if (!checkPassword(password)) {
            return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        }
        if (!phoneNumber(phoneNumber)) {
            return "Phone number incorrectly formatted or does not contain international code.";
        }

        // Save user details
        this.username = username;
        this.password = password;
        this.phoneNumber = phoneNumber;

        return "User registered successfully.";
    }

    // ===============================================================
    //                   LOGIN USER
    // ===============================================================
    // This method checks if the entered username and password match
    public boolean loginUser(String username, String password) {
        return this.username.equals(username) && this.password.equals(password);
    }

    // ===============================================================
    //                   RETURN LOGIN STATUS
    // ===============================================================
    // Returns a message depending on whether login was successful
    public String returnLoginStatus(boolean success) {
        if (success) {
            return "Welcome " + this.username + ", it is great to see you again.";
        } else {
            return "Username or password is incorrect, please try again.";
        }
    }
}